---
name: Micke-Strell Research Identity
colors:
  surface: '#FFFFFF'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdf'
  on-secondary-container: '#626262'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1c'
  on-tertiary-container: '#838484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#e4e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c7c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  accent-warm-grey: '#CFCABE'
  accent-tan: '#C2A990'
  accent-burnt-orange: '#D8613C'
  accent-sage: '#B1C5A4'
  accent-cool-grey: '#B5BDBC'
typography:
  headline-xxl:
    fontFamily: Jost
    fontSize: 3.27rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Jost
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Jost
    fontSize: 1.85rem
    fontWeight: '500'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Jost
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Instrument Sans
    fontSize: 1.05rem
    fontWeight: '400'
    lineHeight: '1.55'
  body-md:
    fontFamily: Instrument Sans
    fontSize: 0.95rem
    fontWeight: '400'
    lineHeight: '1.55'
  label-md:
    fontFamily: Jost
    fontSize: 0.9rem
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: 0.05em
  caption:
    fontFamily: Instrument Sans
    fontSize: 0.8rem
    fontWeight: '400'
    lineHeight: '1.4'
  headline-xxl-mobile:
    fontFamily: Jost
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: '1.15'
  headline-xl-mobile:
    fontFamily: Jost
    fontSize: 1.85rem
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  stack-xs: 1rem
  stack-md: 1.5rem
  stack-lg: 2.5rem
  section-md: 4rem
  section-lg: 6.5rem
  section-xl: 10.5rem
  gutter: 1.2rem
  max-width-content: 620px
  max-width-site: 1280px
---

## Brand & Style

This design system is engineered for the **Micke-Strell Group**, a medical research laboratory specializing in spatial biology and cancer research. The brand personality is **Academic, Precise, and Credible**, prioritizing clarity of information and the sophisticated nature of scientific discovery.

The design style is **Corporate / Modern** with a **Minimalist** foundation. It leverages generous whitespace to create a "gallery-like" feel for research data and microscopy imagery. The aesthetic is defined by:
- **Scientific Precision:** Sharp lines and high-contrast typography reflecting the accuracy of lab work.
- **Organic Professionalism:** A palette of muted, earth-toned accents that humanize the high-tech medical context.
- **Architectural Structure:** A rigorous grid system that organizes complex data into digestible, trustworthy hierarchies.
- **Subtle Modernism:** Geometric sans-serif typefaces paired with functional, pill-shaped UI elements.

## Colors

The palette is rooted in a high-contrast monochromatic base, optimized for long-form reading and technical documentation.

- **Foundational Neutrals:** The background uses a soft off-white (`#F9F9F9`) to reduce eye strain, while pure white (`#FFFFFF`) is reserved for surface-level cards and navigation to create subtle depth.
- **Primary Contrast:** Black (`#111111`) is the authoritative color for all primary text and structural borders.
- **Thematic Accents:** These colors are used sparingly for categorization (e.g., specific research focus areas), data visualization, or subtle section transitions. They should never overwhelm the primary neutral canvas.
- **Gradients:** When transitioning between sections, use linear gradients that move from a 10% opacity named accent color to the base neutral (`#F9F9F9`).

## Typography

The typography system creates a clear distinction between **Editorial/Headlines (Jost)** and **Functional/Body (Instrument Sans)**. 

- **Fluid Scaling:** Headings utilize a clamp-based scale to ensure readability across all devices without losing their rhythmic impact.
- **The Asterisk Style:** For primary headings (`H1`, `H2`), a decorative asterisk symbol may be placed before the text as a marker of scientific notation and detail.
- **Line Length:** To maintain professional legibility, body text should be restricted to a maximum width of `620px` (approx. 70-80 characters).
- **Hierarchy:** Use `label-md` for small eyebrows above headlines to categorize content (e.g., "RESEARCH PAPER", "MEMBER PROFILE").

## Layout & Spacing

This design system uses a **Fixed Grid** philosophy centered on a wide container for structural layout and a narrow container for readability.

- **Content Constraints:** Main reading material is centered within a `620px` column. Visual assets and gallery grids can expand to the `1280px` "Wide" container.
- **Rhythm:** A vertical spacing scale based on a `1.2rem` block gap ensures consistent density.
- **Breakpoints:**
  - **Desktop:** `spacing.section-lg` (`6.5rem`) side padding to create a luxurious sense of space.
  - **Tablet:** `spacing.stack-lg` (`2.5rem`) side padding.
  - **Mobile:** `20px` side padding with a shift to 1-column layouts.
- **Sectioning:** Use large vertical gaps (`section-xl`) to clearly demarcate major shifts in content (e.g., moving from "Research Interests" to "Latest Publications").

## Elevation & Depth

Visual hierarchy is primarily achieved through **Tonal Layers** and **Bold Outlines** rather than soft shadows.

- **The "Sharp" Shadow:** Use hard-edged, non-blurred shadows (`6px 6px 0px rgba(0, 0, 0, 0.2)`) for cards and interactive elements to provide a technical, structured feel.
- **High-Contrast Focus:** Elements requiring immediate attention use the "Crisp" shadow—a pure black, 0-blur offset that mirrors the weight of the typography.
- **Flat Surfaces:** Primary containers should remain flat against the `#F9F9F9` background, using 1px borders (`#111111`) instead of shadows to define boundaries.
- **Micro-interactions:** On hover, a "Sharp" shadow may shift to a "Natural" soft shadow to indicate lift and interactivity.

## Shapes

The shape language is a hybrid of **Precise Geometry** and **Pill-Shaped Softness**.

- **Containers:** Cards and content boxes use **Soft** (4px) corners to maintain a professional, modern look without feeling clinical.
- **Interactive Elements:** Buttons and tags must be **Pill-shaped** (`100px` radius). This contrast against the sharp grid makes functional elements instantly recognizable.
- **Scientific Imagery:** Microscopy and profile photos should use circular masks or very large radii (`rounded-xl`) to contrast against the rigid text layout.

## Components

- **Buttons:**
  - **Primary:** Black fill (`#111111`), white text, Jost medium font, pill-shaped.
  - **Secondary:** Transparent fill, 1px black border, black text.
  - **Hover:** Shift background to `#636363` with a 2px offset focus ring.
- **Research Chips:** Use for tagging keywords (e.g., "Immunology"). Small Jost labels, pill-shaped with a light neutral fill (`#EAEAEA`) or a subtle accent tint.
- **Data Cards:** White surface background, 1px border, and the "Sharp" shadow preset. Header text in Jost, body in Instrument Sans.
- **Input Fields:** Bottom-border only or very light 4px rounded outlines. Focus state should utilize a 2px black outline.
- **Lists:** Research publications should be presented in a "Clean List" format: high vertical padding between items, metadata in `caption` style, and titles in `headline-md`.
- **Navigation:** Minimalist top-bar. Links in Jost label-md style with an underline animation on hover.